module.exports = {
    emptyDorm: {
        name: "",
        img: "",
        desc: "",
        total: 0,
        eating: 0,
        gym_proximity: 0,
        studying: 0,
        availability_first_year_students: false,
        house_type: 'traditional residence hall',
        address: '',
    }
}