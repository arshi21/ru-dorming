### Tutorial: Sequelize CRUD 101

This repo is the companion to [this here blog post](http://lorenstewart.me/2016/10/03/sequelize-crud-101/).

To get started:
 1. make sure you're using Node 6 or greater
 2. `npm install`
 3. `npm run dev`.
